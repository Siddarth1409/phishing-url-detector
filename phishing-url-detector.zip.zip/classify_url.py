import joblib
from features import extract_features
import tldextract

# Load model
model = joblib.load("phishing_model.pkl")

# Input
url = input("Enter a URL to classify: ").strip()

# Check against hardcoded safe domains first
SAFE_DOMAINS = {"google", "microsoft", "github", "linkedin", "openai", "amazon", "youtube"}
ext = tldextract.extract(url)
if ext.domain.lower() in SAFE_DOMAINS:
    print("✅ This URL is from a known SAFE domain.")
else:
    # Predict using model
    features = extract_features(url)
    prediction = model.predict([features])[0]

    if prediction == 1:
        print("⚠️ This URL is likely a PHISHING site.")
    else:
        print("✅ This URL looks SAFE.")
