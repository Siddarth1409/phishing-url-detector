from flask import Flask, render_template, request
import joblib
from features import extract_features
import tldextract
import csv
import os
from datetime import datetime

app = Flask(__name__)

# Load model
model = joblib.load("phishing_model.pkl")
SAFE_DOMAINS = {"google", "microsoft", "github", "linkedin", "openai", "amazon", "youtube"}

HISTORY_FILE = "history.csv"

@app.route("/", methods=["GET", "POST"])
def home():
    result = None
    url = ""

    if request.method == "POST":
        url = request.form["url"]
        ext = tldextract.extract(url)
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        if ext.domain.lower() in SAFE_DOMAINS:
            result = "✅ Known SAFE domain."
            label = "safe"
        else:
            features = extract_features(url)
            prediction = model.predict([features])[0]
            label = "phishing" if prediction == 1 else "safe"
            result = "⚠️ Likely PHISHING site!" if prediction == 1 else "✅ Looks SAFE."

        # ✅ Save to history log
        with open(HISTORY_FILE, "a", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([timestamp, url, label])

    return render_template("index.html", result=result, url=url)

@app.route("/history")
def history():
    logs = []
    if os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, "r") as f:
            reader = csv.reader(f)
            logs = list(reader)
    return render_template("history.html", logs=logs)

if __name__ == "__main__":
    app.run(debug=True)
