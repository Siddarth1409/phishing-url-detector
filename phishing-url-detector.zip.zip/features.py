import tldextract

# Trusted safe domains (manually defined)
SAFE_DOMAINS = {"google", "microsoft", "github", "linkedin", "openai", "amazon", "youtube"}

def extract_features(url):
    features = {}
    features['url_length'] = len(url)
    features['num_dots'] = url.count('.')
    features['has_at_symbol'] = '@' in url
    features['has_hyphen'] = '-' in url
    features['has_https'] = url.startswith('https')
    features['num_digits'] = sum(char.isdigit() for char in url)

    ext = tldextract.extract(url)
    features['subdomain_length'] = len(ext.subdomain)
    features['domain_length'] = len(ext.domain)
    features['suffix'] = 1 if ext.suffix in ['com', 'org', 'net', 'edu'] else 0

    # ✅ NEW: Safe domain check
    features['is_safe_domain'] = 1 if ext.domain.lower() in SAFE_DOMAINS else 0

    # Suspicious words
    suspicious_words = ['login', 'verify', 'update', 'bank', 'account', 'secure', 'ebay', 'paypal']
    features['has_suspicious_word'] = any(word in url.lower() for word in suspicious_words)

    return list(features.values())
