import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import joblib
from features import extract_features

print("Training started...")

# Load and filter data
df = pd.read_csv("dataset.csv")
df = df[df['type'].isin(['phishing', 'benign'])]  # Only phishing or safe
df['label'] = df['type'].apply(lambda x: 1 if x == 'phishing' else 0)

print("Filtered rows:", len(df))

# Extract features
X = df['url'].apply(extract_features).tolist()
y = df['label']

print("Features extracted. Training model...")

# Split and train
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Evaluate
predictions = model.predict(X_test)
accuracy = accuracy_score(y_test, predictions)
print("✅ Model trained. Accuracy:", accuracy)

# Save model
joblib.dump(model, "phishing_model.pkl")
print("✅ Model saved as phishing_model.pkl")
